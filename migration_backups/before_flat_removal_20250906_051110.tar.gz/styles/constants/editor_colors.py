
EDITOR_COLORS = {
    'background': '#1C1C1E',
    'background_darker': '#18181A',
    'text': '#E8E8E8',
    'line_number': '#6C7A89',
    'current_line': '#252529',
    'selection': '#2D4F67',
}