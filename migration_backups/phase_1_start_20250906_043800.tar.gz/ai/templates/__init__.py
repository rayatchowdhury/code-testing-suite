# -*- coding: utf-8 -*-
"""
Template management module.
"""

from .prompt_templates import PromptTemplates

__all__ = ['PromptTemplates']
