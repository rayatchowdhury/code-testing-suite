#this is the window that will display the results of the TLE test
#it contains the two sections: sidebar and display area
#sidebar contains the following buttons:
# - show passed tests
# - show failed tests
# - back button - goes back to the TLE tester window