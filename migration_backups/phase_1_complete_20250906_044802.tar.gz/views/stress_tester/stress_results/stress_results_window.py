# -*- coding: utf-8 -*-
#this is the main window for the stress test results
#it contains the two sections: sidebar and display area
#sidebar contains the following buttons:
# - show passed tests
# - show failed tests
# - back button - goes back to the stress tester window